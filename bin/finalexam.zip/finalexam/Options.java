package finalexam;

public class Options {
	
	public Options() {
		// TODO Auto-generated constructor stub
	}

}
