package finalexam;

import java.util.ArrayList;
import java.util.Collections;

abstract class DbProcessing extends Database{
	
	public ArrayList<QuestionDb> getArrayOfQuestions(int n, ArrayList<QuestionDb> ids){
		return super.getArrayOfQuestions(n);
	}

}
