package finalexam;

import java.util.*;
import java.io.*;

// database class we will be called as an object in Game class
public class Database {
	private ArrayList<QuestionDb> questiondb;
	
	public Database() {
		// TODO Auto-generated constructor stub
	}
	
	protected void init() {
		System.out.println("Setting up Database please wait...");
		QuestionDb question = null;
		for(int i=0; i<15;i++) {
			ArrayList<String> options = new ArrayList<String>();
			options.add("Not fine");
			options.add("Not fine");
			options.add("Not fine");
			options.add("I am fine");
			question = new QuestionDb("How are you?", "I am fine", options);
			this.questiondb.add(question);
		}
		System.out.println("Database setup done!");
	}
	
	// function would be in the game
	public ArrayList<QuestionDb> getArrayOfQuestions(int n){
		ArrayList<QuestionDb> returnQuetionDb = new ArrayList<QuestionDb>();
		Collections.shuffle(this.questiondb);
		do{
			returnQuetionDb.add(questiondb.remove(0));
		}while(returnQuetionDb.size()!=n);
		return returnQuetionDb;
	}

	public ArrayList<QuestionDb> getArrayOfQuestions() {
		return questiondb;
	}


}
